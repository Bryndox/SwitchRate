package com.brianonyando.brian.switchrates;

import android.annotation.TargetApi;
import android.app.ListActivity;
import android.content.CursorLoader;
import android.database.Cursor;
import android.os.Build;
import android.support.v4.content.Loader;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.app.LoaderManager;


@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class Currencies extends  ListActivity implements
        android.app.LoaderManager.LoaderCallbacks<Cursor> {

    private SimpleCursorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currencies);
        populateList();

    }

    @Override
    public android.content.Loader<Cursor> onCreateLoader(int id, Bundle args) {
        String[] projection = { MySQLiteHelper.COLUMN_ID, MySQLiteHelper.COLUMN_ABBRV, MySQLiteHelper.COLUMN_NAME };
        CursorLoader cursorLoader = new CursorLoader(this,
                CurrencyProvider.CONTENT_URI, projection, null, null, null);
        return cursorLoader;
    }

    @Override
    public void onLoadFinished(android.content.Loader<Cursor> loader, Cursor data) {
        adapter.swapCursor(data);
    }

    @Override
    public void onLoaderReset(android.content.Loader<Cursor> loader) {
        adapter.swapCursor(null);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
       // getMenuInflater().inflate(R.menu.menu_currencies, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void populateList(){
        // Fields from the database (projection)
        // Must include the _id column for the adapter to work
        String[] from = new String[] { MySQLiteHelper.COLUMN_ABBRV,MySQLiteHelper.COLUMN_NAME };
        // Fields on the UI to which we map
        int[] to = new int[] { R.id.labelAbbr, R.id.labelName };

        getLoaderManager().initLoader(0, null, this);
        adapter = new SimpleCursorAdapter(this, R.layout.currency_row, null, from,
                to, 0);

        setListAdapter(adapter);

    }
}
