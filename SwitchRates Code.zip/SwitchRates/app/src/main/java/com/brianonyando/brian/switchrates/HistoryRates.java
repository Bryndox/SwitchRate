package com.brianonyando.brian.switchrates;

/**
 * Created by Brian on 3/12/2015.
 */
public class HistoryRates {
    String Date;
    String Value;
    String Converted;

    public HistoryRates(String date, String value, String converted){
        this.Date=date;
        this.Value=value;
        this.Converted=converted;
    }

    public String getDate(){
        return this.Date;
    }

    public String getValue(){
        return this.Value;
    }

    public String getConverted(){
        return this.Converted;
    }
}
