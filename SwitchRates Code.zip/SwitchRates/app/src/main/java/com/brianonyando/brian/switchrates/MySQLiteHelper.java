package com.brianonyando.brian.switchrates;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

/**
 * Created by Brian on 3/22/2015.
 */
public class MySQLiteHelper extends SQLiteOpenHelper {

    public static final String TABLE_CURRENCIES = "currencies";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_ABBRV = "abbrev";
    public static final String COLUMN_NAME = "name";

    private static final String DATABASE_NAME = "currency.db";
    private static final int DATABASE_VERSION = 1;

    // Database creation sql statement
    private static final String DATABASE_CREATE = "create table "
            + TABLE_CURRENCIES + "(" + COLUMN_ID
            + " integer primary key autoincrement, " + COLUMN_ABBRV
            + " text not null, "+ COLUMN_NAME
            + " text not null);";

    public MySQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DATABASE_CREATE);
        String[][] currencies=new String[][]{
                {"AED","Arab Emirates Dirham"},
                {"AFN","Afghanistan Afghani"},
                {"ALL","Albanian Lek"},
                {"AMD","Armenian Dram"},
                {"ANG","Netherlands Antillean Guilder"},
                {"AOA","Angolan Kwanza"},
                {"ARS","Argentine Peso"},
                {"AUD","Australian Dollar"},
                {"AWG","Aruban Guilder"},
                {"AZN","Azerbaijan New Manat"},
                {"BAM","Bosnia-Herzegovina Convertible Mark"},
                {"BBD","Barbados Dollar"},
                {"BDT","Bangladeshi Taka"},
                {"BGN","Bulgarian Lev"},
                {"BHD","Bahraini Dinar"},
                {"BIF","Burundi Franc"},
                {"BMD","Bermudian Dollar"},
                {"BND","Brunei Dollar"},
                {"BOB","Boliviano"},
                {"BRL","Brazilian Real"},
                {"BSD","Bahamian Dollar"},
                {"BTN","Bhutan Ngultrum"},
                {"BWP","Botswana Pula"},
                {"BYR","Belarussian Ruble"},
                {"BZD","Belize Dollar"},
                {"CAD","Canadian Dollar"},
                {"CDF","Congolese Franc"},
                {"CHF","Swiss Franc"},
                {"CLF","Unidad de Fomento"},
                {"CLP","Chilean Peso"},
                {"CNH","Offshore Yuan Renminbi"},
                {"CNY","Yuan Renminbi"},
                {"COP","Colombian Peso"},
                {"CRC","Costa Rican Colon"},
                {"CUP","Cuban Peso"},
                {"CVE","Cape Verde Escudo"},
                {"CZK","Czech Koruna"},
                {"DJF","Djibouti Franc"},
                {"DKK","Danish Krone"},
                {"DOP","Dominican Peso"},
                {"DZD","Algerian Dinar"},
                {"EGP","Egyptian Pound"},
                {"ERN","Eritrean Nakfa"},
                {"ETB","Ethiopian Birr"},
                {"EUR","Euro"},
                {"FJD","Fiji Dollar"},
                {"FKP","Falkland Islands Pound"},
                {"GBP","Pound Sterling"},
                {"GEL","Georgian Lari"},
                {"GHS","Ghanaian Cedi"},
                {"GIP","Gibraltar Pound"},
                {"GMD","Gambian Dalasi"},
                {"GNF","Guinea Franc"},
                {"GTQ","Guatemalan Quetzal"},
                {"GYD","Guyana Dollar"},
                {"HKD","Hong Kong Dollar"},
                {"HNL","Honduran Lempira"},
                {"HRK","Croatian Kuna"},
                {"HTG","Haitian Gourde"},
                {"HUF","Hungarian Forint"},
                {"IDR","Indonesian Rupiah"},
                {"IEP","Irish Pound (replaced by EUR)"},
                {"ILS","Israeli New Shekel"},
                {"INR","Indian Rupee"},
                {"IQD","Iraqi Dinar"},
                {"IRR","Iranian Rial"},
                {"ISK","Iceland Krona"},
                {"JMD","Jamaican Dollar"},
                {"JOD","Jordanian Dinar"},
                {"JPY","Japanese Yen"},
                {"KES","Kenyan Shilling"},
                {"KGS","Kyrgyzstani Som"},
                {"KHR","Kampuchean Riel"},
                {"KMF","Comoros Franc"},
                {"KPW","North Korean Won"},
                {"KRW","Korean Won"},
                {"KWD","Kuwaiti Dinar"},
                {"KYD","Cayman Islands Dollar"},
                {"KZT","Kazakhstan Tenge"},
                {"LAK","Lao Kip"},
                {"LBP","Lebanese Pound"},
                {"LKR","Sri Lanka Rupee"},
                {"LRD","Liberian Dollar"},
                {"LSL","Lesotho Loti"},
                {"LTL","Lithuanian Litas"},
                {"LVL","Latvian Lats"},
                {"LYD","Libyan Dinar"},
                {"MAD","Moroccan Dirham"},
                {"MDL","Moldovan Leu"},
                {"MGA","Malagasy Ariary"},
                {"MKD","Macedonian Denar"},
                {"MMK","Myanmar Kyat"},
                {"MNT","Mongolian Tugrik"},
                {"MOP","Macau Pataca"},
                {"MRO","Mauritanian Ouguiya"},
                {"MUR","Mauritius Rupee"},
                {"MVR","Maldive Rufiyaa"},
                {"MWK","Malawi Kwacha"},
                {"MXN","Mexican Nuevo Peso"},
                {"MXV","Mexican Unidad de Inversion"},
                {"MYR","Malaysian Ringgit"},
                {"MZN","Mozambique Metical"},
                {"NAD","Namibian Dollar"},
                {"NGN","Nigerian Naira"},
                {"NIO","Nicaraguan Cordoba Oro"},
                {"NOK","Norwegian Krone"},
                {"NPR","Nepalese Rupee"},
                {"NZD","New Zealand Dollar"},
                {"OMR","Omani Rial"},
                {"PAB","Panamanian Balboa"},
                {"PEN","Peruvian Nuevo Sol"},
                {"PGK","Papua New Guinea Kina"},
                {"PHP","Philippine Peso"},
                {"PKR","Pakistan Rupee"},
                {"PLN","Polish Zloty"},
                {"PYG","Paraguay Guarani"},
                {"QAR","Qatari Rial"},
                {"RON","Romanian New Leu"},
                {"RSD","Serbian Dinar"},
                {"RUB","Russian Ruble"},
                {"RWF","Rwanda Franc"},
                {"SAR","Saudi Riyal"},
                {"SBD","Solomon Islands Dollar"},
                {"SCR","Seychelles Rupee"},
                {"SDG","Sudanese Pound"},
                {"SEK","Swedish Krona"},
                {"SGD","Singapore Dollar"},
                {"SHP","St. Helena Pound"},
                {"SLL","Sierra Leone Leone"},
                {"SOS","Somali Shilling"},
                {"SRD","Surinam Dollar"},
                {"STD","São Tomé and Príncipe Dobra"},
                {"SVC","El Salvador Colon"},
                {"SYP","Syrian Pound"},
                {"SZL","Swaziland Lilangeni"},
                {"THB","Thai Baht"},
                {"TJS","Tajik Somoni"},
                {"TMT","Turkmenistani Manat"},
                {"TND","Tunisian Dollar"},
                {"TOP","Tongan Pa'anga"},
                {"TRY","Turkish Lira"},
                {"TTD","Trinidad and Tobago Dollar"},
                {"TWD","Taiwan Dollar"},
                {"TZS","Tanzanian Shilling"},
                {"UAH","Ukraine Hryvnia"},
                {"UGX","Uganda Shilling"},
                {"USD","US Dollar"},
                {"UYU","Uruguayan Peso"},
                {"UZS","Uzbekistan Sum"},
                {"VEF","Venezuelan Bolivar"},
                {"VND","Vietnamese Dong"},
                {"VUV","Vanuatu Vatu"},
                {"WST","Samoan Tala"},
                {"XAF","CFA Franc BEAC"},
                {"XAG","Silver Ounce"},
                {"XAU","Gold Ounce"},
                {"XBT","Bitcoin"},
                {"XCD","East Caribbean Dollar"},
                {"XCP","Ounces of Copper"},
                {"XDR","IMF Special Drawing Rights"},
                {"XOF","CFA Franc BCEAO"},
                {"XPD","Palladium Ounce"},
                {"XPF","CFP Franc"},
                {"XPT","Platinum Ounce"},
                {"YER","Yemeni Rial"},
                {"ZAR","South African Rand"},
                {"ZMW","Zambian Kwacha"},
                {"ZWL","Zimbabwe Dollar"}
        };
        String sql = "INSERT INTO "+ TABLE_CURRENCIES +" VALUES (?,?,?);";
        SQLiteStatement statement = db.compileStatement(sql);
        db.beginTransaction();
        for (int i = 0; i<currencies.length; i++) {
            statement.clearBindings();
            statement.bindString(2, currencies[i][0]);
            statement.bindString(3, currencies[i][1]);
            statement.execute();
        }
        db.setTransactionSuccessful();
        db.endTransaction();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(MySQLiteHelper.class.getName(),
                "Upgrading database from version " + oldVersion + " to "
                        + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CURRENCIES);
        onCreate(db);
    }
}
