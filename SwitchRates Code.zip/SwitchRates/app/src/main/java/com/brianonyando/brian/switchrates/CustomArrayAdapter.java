package com.brianonyando.brian.switchrates;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Brian on 3/12/2015.
 */
public class CustomArrayAdapter extends BaseAdapter {


    private final Context context;
    private final HistoryRates[] historyValues;

    public CustomArrayAdapter(Context context, HistoryRates[] values) {
       // super(context, R.layout.history_list_item, new String[]{});
        this.context = context;
        this.historyValues = values;
    }

    @Override
    public int getCount() {
        return historyValues.length;
    }

    @Override
    public Object getItem(int position) {
        return historyValues[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.history_list_item, parent, false);
        TextView textDate = (TextView) rowView.findViewById(R.id.textViewHistoryDate);
        TextView textValue = (TextView) rowView.findViewById(R.id.textViewHistoryValue);
        TextView textConverted = (TextView) rowView.findViewById(R.id.textViewHistoryConverted);

        textDate.setText(this.historyValues[position].getDate().toString());
        textValue.setText(this.historyValues[position].getValue().toString());
        textConverted.setText(this.historyValues[position].getConverted().toString());

        return rowView;
    }
}
