package com.brianonyando.brian.switchrates;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;

/**
 * Created by Brian on 3/23/2015.
 */
public class FetchHTTPData extends IntentService {
    /**
     * Creates an IntentService.  Invoked by your subclass's constructor.
     *
     * @param name Used to name the worker thread, important only for debugging.
     */
    // Defines a custom Intent action
    public static final String BROADCAST_ACTION =
            "com.brianonyando.brian.switchrates.BROADCAST";

    // Defines the key for the status "extra" in an Intent
    public static final String EXTENDED_DATA_STATUS =
            "com.brianonyando.brian.switchrates.STATUS";

    public FetchHTTPData() {
        super("FetchHTTPData");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Bundle bundle=intent.getExtras();

        String fromDate= bundle.getString(HistoryFragment.FROM_DATE);
        String toDate= bundle.getString(HistoryFragment.TO_DATE);
        String fromCurrency= bundle.getString(HistoryFragment.FROM_CURRENCY);
        String toCurrency= bundle.getString(HistoryFragment.TO_CURRENCY);
        String amount= bundle.getString(HistoryFragment.AMOUNT);

        HistoryRates[] hRates=HTTPConnection.HTTPFetchHistoryRates(fromDate, toDate, fromCurrency, toCurrency,amount, getApplicationContext());


        if(hRates!=null){
            String [] rates=new String[hRates.length];
            for(int i=0; i<hRates.length; i++){
                rates[i]=hRates[i].Date+","+hRates[i].Value+","+hRates[i].Converted;
            }

            Bundle b=new Bundle();
            b.putStringArray(HistoryFragment.results,rates);
            Intent localIntent =
                    new Intent(BROADCAST_ACTION)
                            .putExtras( b);
            // Broadcasts the Intent to receivers in this app.
            LocalBroadcastManager.getInstance(this).sendBroadcast(localIntent);
        }

        else{

            Intent localIntent =
                    new Intent(BROADCAST_ACTION)
                            // Puts the status into the Intent
                            .putExtra(EXTENDED_DATA_STATUS, "Could not fetch history values");
            // Broadcasts the Intent to receivers in this app.
            LocalBroadcastManager.getInstance(this).sendBroadcast(localIntent);
        }

    }
}
