package com.brianonyando.brian.switchrates;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Brian on 3/17/2015.
 */
public class HistoryFragment extends Fragment {

    private View mLoadingView;
    int mShortAnimationDuration;
    ListView historyListView;
    String amount;
    String fromCurrency;
    String toCurrency;
    TextView averageTxtView, textHeaderDate, textHeaderFrom, textHeaderTo, textHeader;
    CustomArrayAdapter adapter;
    public static int historyDays=30;

    public boolean twoPane=false;

    public static String FROM_DATE="from_date";
    public static String TO_DATE="to_date";
    public static String FROM_CURRENCY="from_currency";
    public static String TO_CURRENCY="to_currency";
    public static String AMOUNT="amount";
    public static String results="results";

    public static String from_Currency;
    public static String to_Currency;

    public HistoryFragment() {
    }

    public void useTwoPane(boolean twoPane){
        RatesFormFragment.twoPane=twoPane;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu,  MenuInflater inflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        inflater.inflate(R.menu.menu_main, menu);

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_currency) {
            Intent i = new Intent(getActivity(), Currencies.class);
            startActivity(i);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // The filter's action is BROADCAST_ACTION
        IntentFilter mStatusIntentFilter = new IntentFilter(
                FetchHTTPData.BROADCAST_ACTION);

        // Instantiates a new DownloadStateReceiver
        ResponseReceiver mDownloadStateReceiver =
                new ResponseReceiver();
        // Registers the DownloadStateReceiver and its intent filters
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(
                mDownloadStateReceiver,
                mStatusIntentFilter);


        // Adds a data filter for the HTTP scheme
       // mStatusIntentFilter.addDataScheme("http");*/

        View rootView = inflater.inflate(R.layout.fragment_history, container, false);
        textHeader=(TextView)rootView.findViewById(R.id.textViewHistoryHeader);
        textHeader.setText(historyDays+" Days History");

        historyListView=(ListView)rootView.findViewById(R.id.HistorylistView);
        averageTxtView=(TextView)rootView.findViewById(R.id.textViewAverage);
        textHeaderDate=(TextView)rootView.findViewById(R.id.textViewHistoryHeaderDate);
        textHeaderFrom=(TextView)rootView.findViewById(R.id.textViewHistoryHeaderFrom);
        textHeaderTo=(TextView)rootView.findViewById(R.id.textViewHistoryHeaderTo);
        mLoadingView = rootView.findViewById(R.id.loading_spinner_history);
        mLoadingView.setVisibility(View.GONE);


        if(getActivity().getIntent()!=null && RatesFormFragment.twoPane==false){
            //set progress dialog if one pane view
            mLoadingView.setAlpha(0f);
            mLoadingView.setVisibility(View.VISIBLE);

            // Animate the content view to 100% opacity, and clear any animation
            // listener set on the view.
            mShortAnimationDuration = getResources().getInteger(
                    android.R.integer.config_shortAnimTime);


            mLoadingView.animate()
                    .alpha(1f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(null);
            Bundle extras = getActivity().getIntent().getExtras();

            // Extract data using passed keys
            this.amount = extras.getString("Amount");
            this.fromCurrency = extras.getString("fromCurrency");
            this.toCurrency = extras.getString("toCurrency");


            //convert amount to integer, then to string
            String amt=String.valueOf(Double.valueOf(this.amount));

            //Get todays date and tha date 7 days ago
            Calendar cal = Calendar.getInstance();
            Date dateNow=cal.getTime();
            SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");
            String todayDate=df.format(dateNow);


            cal.add(Calendar.DAY_OF_YEAR,-historyDays);
            Date datePast=cal.getTime();
            String pastDate=df.format(datePast);

            textHeaderDate.setText("Date");
            textHeaderFrom.setText(fromCurrency);
            textHeaderTo.setText(toCurrency);


            // new FetchHistoryRates().execute(pastDate,todayDate,fromCurrency,toCurrency, amt);
            Intent intent = new Intent(getActivity(), FetchHTTPData.class);

            intent.putExtra(FROM_DATE,pastDate);
            intent.putExtra(TO_DATE,todayDate);
            intent.putExtra(FROM_CURRENCY,fromCurrency);
            intent.putExtra(TO_CURRENCY,toCurrency);
            intent.putExtra(AMOUNT,amt);

            getActivity().startService(intent);

        }


        return rootView;
    }

    // Broadcast receiver for receiving status updates from the IntentService
    private class ResponseReceiver extends BroadcastReceiver
    {

        // Called when the BroadcastReceiver gets an Intent it's registered to receive

        public void onReceive(Context context, Intent intent) {

        /*
         * Handle Intents here.
         */
            if( RatesFormFragment.twoPane==false){
                //remove progress dialog
                mLoadingView.animate()
                        .alpha(0f)
                        .setDuration(mShortAnimationDuration)
                        .setListener(new AnimatorListenerAdapter() {
                            @Override
                            public void onAnimationEnd(Animator animation) {
                                mLoadingView.setVisibility(View.GONE);
                            }
                        });

            }

            if(intent.getStringExtra(FetchHTTPData.EXTENDED_DATA_STATUS)!=null){
                Toast.makeText(getActivity(),intent.getStringExtra(FetchHTTPData.EXTENDED_DATA_STATUS),Toast.LENGTH_LONG).show();
            }
            else{
                String[] results=intent.getStringArrayExtra(HistoryFragment.results);
                HistoryRates [] rates=new HistoryRates[results.length];
                Double average=0.0;

                for(int i=0; i<results.length; i++){
                    String[] daysValue= results[i].split(",");
                    rates[i]=new HistoryRates(daysValue[0],daysValue[1],daysValue[2]);
                    average+=Double.valueOf(daysValue[2]);
                }

                average/=rates.length;

                //Update UI


                //set header
                textHeaderDate.setText("Date");
                textHeaderFrom.setText(from_Currency);
                textHeaderTo.setText(to_Currency);

                averageTxtView.setText("Average value: "+String.format("%.2f", average));
                adapter = new CustomArrayAdapter(getActivity(), rates);
                historyListView.setAdapter(adapter);
                //Toast.makeText(getActivity(), "Values gotten "+results.length,Toast.LENGTH_LONG).show();
            }

        }
    }


}