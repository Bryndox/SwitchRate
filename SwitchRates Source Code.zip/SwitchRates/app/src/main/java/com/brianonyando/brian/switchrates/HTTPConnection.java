package com.brianonyando.brian.switchrates;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Currency;
import java.util.Iterator;
import java.util.List;

/**
 * Created by Brian on 3/8/2015.
 */
public class HTTPConnection {


    //Format JSON current rate value String
    private static String[] JSONCurrentFormatter(String JSONString, String toCurrency){
        String result[]=new String[2];
        try {
            JSONObject obj=new JSONObject(JSONString);
            result[0]="noError";
            result[1]=String.format("%.2f",Double.valueOf(obj.getString("amount")))+" "+toCurrency;
        } catch (JSONException e) {
            e.printStackTrace();
            result[0]="Error";
            result[1]=e.toString();
        }
        return result;
    }

    //Format JSON history rate value String
    private static HistoryRates[] JSONHistoryFormatter(String JSONString, String Amount, Context context){

        try {
            JSONObject obj=new JSONObject(JSONString);
            JSONObject rates=obj.getJSONObject("rates");
            int count=0;
            if(rates!=null && rates.length()>0) {
                HistoryRates [] historyValues=new HistoryRates[rates.length()];
                for(Iterator iterator = rates.keys(); iterator.hasNext();) {
                    String key = (String) iterator.next();
                    JSONObject objc=rates.getJSONObject(key);

                    HistoryRates historyRate=new HistoryRates(key,Amount,String.format("%.2f",Double.valueOf(objc.getString("rate"))*Double.valueOf(Amount)));

                    historyValues[count]=historyRate;
                    count++;
                }



                return historyValues;
             }
            else {

                return null;
            }

        } catch (JSONException e) {

            return null;
        }

    }


     //function to  fetch rates from web API
    public static String[] HTTPFetchExchangeRates(String value, String fromCurrency, String toCurrency){
        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;

        //API KEY
        String JSONRatesAPIKey="jr-92100c626abeaa927635f526525ccc36";

        // Will contain the raw JSON response as a string.
         String convertedAmount = null;

        try {
        // Construct the URL for the JSON Rates query

        URL url = new URL("http://jsonrates.com/convert/?from="+fromCurrency+"&to="+toCurrency +"&amount="+value+"&apiKey="+JSONRatesAPIKey);

        // Create the request to OpenWeatherMap, and open the connection
        urlConnection = (HttpURLConnection) url.openConnection();
        urlConnection.setRequestMethod("GET");
        urlConnection.connect();

        // Read the input stream into a String
        InputStream inputStream = urlConnection.getInputStream();
        StringBuffer buffer = new StringBuffer();
        if (inputStream == null) {
            // Nothing to do.
            String[] result=new String[]{"Error","Could not Fetch Conversion data :-("};
            return result;
         }
        reader = new BufferedReader(new InputStreamReader(inputStream));

        String line;
        while ((line = reader.readLine()) != null) {
            // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
            // But it does make debugging a *lot* easier if you print out the completed
            // buffer for debugging.
            buffer.append(line+  "\n");
            }

            if (buffer.length() == 0) {
            // Stream was empty.  No point in parsing.
                String[] result=new String[]{"Error","The API call did not return a result :-("};
                return result;
             }
            convertedAmount = buffer.toString();
    } catch (IOException e) {
        Log.e("RatesFormFragment", "Error ", e);
        // If the code didn't successfully get the conversion rate data, there's no point in attemping
        // to parse it.
            String[] result=new String[]{"Error",e.toString()};
            return result;
    } finally{
        if (urlConnection != null) {
                urlConnection.disconnect();
            }
        if (reader != null) {
                try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e("RatesFormFragment", "Error closing stream", e);
                    }
            }
            }
        return JSONCurrentFormatter(convertedAmount, toCurrency);
    }


    //function to  fetch rates from web API
    public static HistoryRates[] HTTPFetchHistoryRates(String startDate, String endDate, String fromCurrency, String toCurrency, String amount, Context context){
        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;

        //API KEY
        String JSONRatesAPIKey="jr-92100c626abeaa927635f526525ccc36";

        // Will contain the raw JSON response as a string.
        String historyValues = null;

        try {
            // Construct the URL for the JSON Rates query
            URL url = new URL("http://jsonrates.com/historical/?from="+fromCurrency+"&to="+toCurrency+"&dateStart="+startDate+"&dateEnd="+endDate+"&apiKey="+JSONRatesAPIKey);

            // Create the request to OpenWeatherMap, and open the connection
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            // Read the input stream into a String
            InputStream inputStream = urlConnection.getInputStream();
            StringBuffer buffer = new StringBuffer();
            if (inputStream == null) {
                // Nothing to do.
                //Toast.makeText(context, "There was an error in parsing data from the server. Please try later :-(",Toast.LENGTH_LONG).show();
                return null;
            }
            reader = new BufferedReader(new InputStreamReader(inputStream));

            String line;
            while ((line = reader.readLine()) != null) {
                // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
                // But it does make debugging a *lot* easier if you print out the completed
                // buffer for debugging.
                buffer.append(line+  "\n");
            }

            if (buffer.length() == 0) {
                // Stream was empty.  No point in parsing.
               // Toast.makeText(context, "The API call did not return a result :-(",Toast.LENGTH_LONG).show();
                return null;
            }
            historyValues = buffer.toString();
        } catch (IOException e) {
            Log.e("RatesFormFragment", "Error ", e);
            // If the code didn't successfully get the conversion rate data, there's no point in attemping
            // to parse it.
            //Toast.makeText(context, "Cannot connect to the internet. Please try later :-(",Toast.LENGTH_LONG).show();
            return null;
        } finally{
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                    Log.e("RatesFormFragment", "Error closing stream", e);
                }
            }
        }
        return JSONHistoryFormatter(historyValues,amount, context);
    }
}
