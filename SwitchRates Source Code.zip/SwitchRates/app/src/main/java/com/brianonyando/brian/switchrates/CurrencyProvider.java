package com.brianonyando.brian.switchrates;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.database.SQLException;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

/**
 * Created by Brian on 3/22/2015.
 */
public class CurrencyProvider extends ContentProvider {

    static final String PROVIDER_NAME = "com.brianonyando.brian.switchrates";
    static final String URL = "content://" + PROVIDER_NAME + "/"+MySQLiteHelper.TABLE_CURRENCIES;
    static final Uri CONTENT_URI = Uri.parse(URL);

    static final String _ID = MySQLiteHelper.COLUMN_ID;
    static final String NAME = MySQLiteHelper.COLUMN_NAME;
    static final String ABBRV = MySQLiteHelper.COLUMN_ABBRV;

    SQLiteDatabase db;

    private static HashMap<String, String> CURRENCY_PROJECTION_MAP;

    static final int CURRENCIES = 1;
    static final int CURRENCIES_ID = 2;

    static final UriMatcher uriMatcher;
    static{
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(PROVIDER_NAME, MySQLiteHelper.TABLE_CURRENCIES, CURRENCIES);
        uriMatcher.addURI(PROVIDER_NAME, MySQLiteHelper.TABLE_CURRENCIES+"/#", CURRENCIES_ID);
    }


    @Override
    public boolean onCreate() {
        Context context = getContext();
        MySQLiteHelper dbHelper = new MySQLiteHelper(context);

        db = dbHelper.getWritableDatabase();
        return (db == null)? false:true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        // Uisng SQLiteQueryBuilder instead of query() method
        SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();

        // check if the caller has requested a column which does not exists
        checkColumns(projection);

        // Set the table
        queryBuilder.setTables(MySQLiteHelper.TABLE_CURRENCIES);

        int uriType = uriMatcher.match(uri);
        switch (uriType) {
            case CURRENCIES:
                queryBuilder.setProjectionMap(CURRENCY_PROJECTION_MAP);
                break;
            case CURRENCIES_ID:
                // adding the ID to the original query
                queryBuilder.appendWhere( MySQLiteHelper.COLUMN_ID + "=" + uri.getPathSegments().get(1));
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }

        if (sortOrder == null || sortOrder == ""){
            /**
             * By default sort on student names
             */
            sortOrder = MySQLiteHelper.COLUMN_ABBRV;
        }
        Cursor cursor = queryBuilder.query(db,	projection,	selection, selectionArgs,
                null, null, sortOrder);
        /**
         * register to watch a content URI for changes
         */
        cursor.setNotificationUri(getContext().getContentResolver(), uri);

        return cursor;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        /**
         * Add a new student record
         */
        long rowID = db.insert(	MySQLiteHelper.TABLE_CURRENCIES, "", values);
        /**
         * If record is added successfully
         */
        if (rowID > 0)
        {
            Uri _uri = ContentUris.withAppendedId(CONTENT_URI, rowID);
            getContext().getContentResolver().notifyChange(_uri, null);
            return _uri;
        }
        throw new SQLException("Failed to add a record into " + uri);
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        int count = 0;

        switch (uriMatcher.match(uri)){
            case CURRENCIES:
                count = db.delete(MySQLiteHelper.TABLE_CURRENCIES, selection, selectionArgs);
                break;
            case CURRENCIES_ID:
                String id = uri.getPathSegments().get(1);
                count = db.delete( MySQLiteHelper.TABLE_CURRENCIES, MySQLiteHelper.COLUMN_ID +  " = " + id +
                        (!TextUtils.isEmpty(selection) ? " AND (" +
                                selection + ')' : ""), selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }

        getContext().getContentResolver().notifyChange(uri, null);
        return count;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        int count = 0;

        switch (uriMatcher.match(uri)){
            case CURRENCIES:
                count = db.update(MySQLiteHelper.TABLE_CURRENCIES, values,
                        selection, selectionArgs);
                break;
            case CURRENCIES_ID:
                count = db.update(MySQLiteHelper.TABLE_CURRENCIES, values, MySQLiteHelper.COLUMN_ID +
                        " = " + uri.getPathSegments().get(1) +
                        (!TextUtils.isEmpty(selection) ? " AND (" +
                                selection + ')' : ""), selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri );
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return count;
    }

    private void checkColumns(String[] projection) {
        String[] available = {MySQLiteHelper.COLUMN_ID,
                MySQLiteHelper.COLUMN_NAME, MySQLiteHelper.COLUMN_ABBRV};
        if (projection != null) {
            HashSet<String> requestedColumns = new HashSet<String>(Arrays.asList(projection));
            HashSet<String> availableColumns = new HashSet<String>(Arrays.asList(available));
            // check if all columns which are requested are available
            if (!availableColumns.containsAll(requestedColumns)) {
                throw new IllegalArgumentException("Unknown columns in projection");
            }
        }
    }
}
