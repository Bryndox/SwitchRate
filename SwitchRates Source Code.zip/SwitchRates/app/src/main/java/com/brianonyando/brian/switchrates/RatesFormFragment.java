package com.brianonyando.brian.switchrates;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;

/**
 * Created by Brian on 3/8/2015.
 */
public  class RatesFormFragment extends Fragment {
    TextView ConvertedRates;
    EditText inputValue;
    Button convertButton;
    String convertedAmount;
    private View mLoadingView;
    int mShortAnimationDuration;
    public static boolean twoPane;
    Spinner spinnerFrom;
    Spinner spinnerTo;


    public RatesFormFragment() {
    }

    public void useTwoPane(boolean twoPane){
        this.twoPane=twoPane;
        if(!twoPane) {

            //Add event listener to text-view
            ConvertedRates.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (convertedAmount != null && convertedAmount.substring(0, 1) != "0") {
                        Intent i = new Intent(getActivity(), HistoryActivity.class);
                        i.putExtra("Amount", convertedAmount);
                        i.putExtra("fromCurrency", spinnerFrom.getSelectedItem().toString());
                        i.putExtra("toCurrency", spinnerTo.getSelectedItem().toString());
                        startActivity(i);
                    }

                }
            });
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu,  MenuInflater inflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
         inflater.inflate(R.menu.menu_main, menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_currency) {
            Intent i = new Intent(getActivity(), Currencies.class);
            startActivity(i);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_main, container, false);
        ConvertedRates=(TextView)rootView.findViewById(R.id.TextViewconvertedRate);
        inputValue=(EditText)rootView.findViewById(R.id.editTextInput);
        convertButton=(Button)rootView.findViewById(R.id.buttonConvert);
        mLoadingView = rootView.findViewById(R.id.loading_spinner_main);
        mLoadingView.setVisibility(View.GONE);

        convertButton.setEnabled(false);

        inputValue.addTextChangedListener(new TextWatcher(){
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            public void afterTextChanged(Editable s) {
                if(inputValue.getText().toString().length()>0){
                    convertButton.setEnabled(true);
                }
                else
                    convertButton.setEnabled(false);

            }

        });

        /* Set the FROM spinner Adapter */
        spinnerFrom = (Spinner)rootView.findViewById(R.id.spinnerFrom);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterFrom = ArrayAdapter.createFromResource(getActivity(),
                R.array.currency_array, R.layout.spinnet_layout);
        // Specify the layout to use when the list of choices appears
        adapterFrom.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinnerFrom.setAdapter(adapterFrom);


        /* Set the TO spinner Adapter */
        spinnerTo = (Spinner)rootView.findViewById(R.id.spinnerTo);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterTo = ArrayAdapter.createFromResource(getActivity(),
                R.array.currency_array, R.layout.spinnet_layout);
        // Specify the layout to use when the list of choices appears
        adapterTo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinnerTo.setAdapter(adapterTo);


        //Set the default value of converted rate to 0
        ConvertedRates.setText("0 "+spinnerTo.getSelectedItem().toString());




        //Add event listener to convert button
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Set the content view to 0% opacity but visible, so that it is visible
                // (but fully transparent) during the animation.
                if (Build.VERSION.SDK_INT < 11) {
                    mLoadingView.setAlpha(0);
                } else{
                    mLoadingView.setAlpha(0f);
                }


                mLoadingView.setVisibility(View.VISIBLE);

                // Animate the content view to 100% opacity, and clear any animation
                // listener set on the view.
               mShortAnimationDuration = getResources().getInteger(
                        android.R.integer.config_shortAnimTime);


                mLoadingView.animate()
                        .alpha(1f)
                        .setDuration(mShortAnimationDuration)
                        .setListener(null);


                String value = inputValue.getText().toString();
                convertedAmount=value;
                String toCurrency = spinnerTo.getSelectedItem().toString();
                String fromCurrency = spinnerFrom.getSelectedItem().toString();

                HistoryFragment.from_Currency=fromCurrency;
                HistoryFragment.to_Currency=toCurrency;
                new FetchConvertedRates().execute(value,fromCurrency,toCurrency,"Current");



            }
        });
        return rootView;
    }


    //AsyncTask class for background thread
    private class FetchConvertedRates extends AsyncTask<String, Void, String[]> {
        @Override
        protected String[] doInBackground(String... params) {
            String[] results=new String[]{};
            if(params[3].equals("Current")){

                results=HTTPConnection.HTTPFetchExchangeRates(params[0],params[1],params[2]);
            }
            else if(params[3].equals("History")){
                results=HTTPConnection.HTTPFetchExchangeRates(params[0],params[1],params[2]);
            }

            return results;
        }


        protected void onPostExecute(String[] result) {

            mLoadingView.animate()
                    .alpha(0f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            mLoadingView.setVisibility(View.GONE);
                        }
                    });

            if(result[0].equals("noError")){
                ConvertedRates.setText(result[1]);

                //if in two pane mode, fetch the history data when converting currency
                if(twoPane){

                    //Get todays date and tha date 7 days ago
                    Calendar cal = Calendar.getInstance();
                    Date dateNow=cal.getTime();
                    SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");
                    String todayDate=df.format(dateNow);


                    cal.add(Calendar.DAY_OF_YEAR,-HistoryFragment.historyDays);
                    Date datePast=cal.getTime();
                    String pastDate=df.format(datePast);
                    Intent intent = new Intent(getActivity(), FetchHTTPData.class);

                    intent.putExtra(HistoryFragment.FROM_DATE,pastDate);
                    intent.putExtra(HistoryFragment.TO_DATE,todayDate);
                    intent.putExtra(HistoryFragment.FROM_CURRENCY,HistoryFragment.from_Currency);
                    intent.putExtra(HistoryFragment.TO_CURRENCY,HistoryFragment.to_Currency);
                    intent.putExtra(HistoryFragment.AMOUNT,convertedAmount);

                    getActivity().startService(intent);
                }
                else{
                    Toast.makeText(getActivity(), "Touch on the converted value text to see history values!", Toast.LENGTH_LONG).show();
                }
            }
            else
                Toast.makeText(getActivity(), "Please check on your internet connection!", Toast.LENGTH_SHORT).show();

        }
    }


}
